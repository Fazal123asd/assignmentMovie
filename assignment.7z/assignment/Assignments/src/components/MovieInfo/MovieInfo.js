import React, { Component } from 'react'
import {  DialogTitle, Dialog, DialogContent, DialogContentText } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    formControl: {
        margin: theme.spacing(1),
        width: 500,
    },
    selectEmpty: {
        marginTop: theme.spacing(2),
    },
})


export default withStyles(styles)(class extends Component {
    render() {

        const { open, onClose, data:{Actors, Awards, BoxOffice, Country, DVD, Director, Genre, Language, Metascore, Plot, imdbRating} } = this.props
        console.log(Actors)
        return (
            <React.Fragment>

                <Dialog open={open} onClose={onClose} aria-labelledby="form-dialog-title">
                    <DialogTitle id="form-dialog-title">Movie More Details</DialogTitle>
                    <DialogContent>
                       <DialogContentText>
                            <strong>Actors:</strong> {Actors} 
                            <br/>
                            <strong>Awards:</strong> {Awards} 
                            <br/>
                            <strong>BoxOffice:</strong> {BoxOffice} 
                            <br/>
                            <strong>Country:</strong> {Country} 
                            <br/>
                            <strong>DVD:</strong> {DVD} 
                            <br/>
                            <strong>Director:</strong> {Director} 
                            <br/>
                            <strong>Genre:</strong> {Genre} 
                            <br/>
                            <strong>Language:</strong> {Language} 
                            <br/>
                            <strong>Metascore:</strong> {Metascore} 
                            <br/>
                            <strong>Plot:</strong> {Plot} 
                            <br/>
                            <strong>boxoffice:</strong> {parseFloat(imdbRating) > 7 ? "Hit": "Flop"} 
                            <br/>
  
                        </DialogContentText>


                    </DialogContent>

                </Dialog>
            </React.Fragment>
        )
    }
}
)
