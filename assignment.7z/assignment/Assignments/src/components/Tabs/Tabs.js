import React from 'react'
import {Paper, Tabs, Tab} from '@material-ui/core'
import {tabs} from '../../store'

export default ({category, onSelect}) =>{
  console.log(category)
  const index =  tabs.findIndex(tab => tab === category) 
  console.log(index)
    return(
        <Paper square>
        <Tabs
          value={index}
          onChange={(e, index)=>{
            onSelect(tabs[index] )
        }}
          indicatorColor="primary"
          textColor="primary"
        
        >
            <Tab label="Tab One" />
            <Tab label="Tab Two" />
           

        </Tabs>
      </Paper>
    )
}

