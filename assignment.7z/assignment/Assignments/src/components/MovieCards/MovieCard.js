import React,{useState} from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { Card, CardActionArea, CardActions, CardContent, CardMedia, Button, Typography } from '@material-ui/core';
import {fetchInfoOfMovie} from '../Api/Api'
import MovieInfo from '../MovieInfo/MovieInfo';

const useStyles = makeStyles({
    root: {
      maxWidth: 345,
      marginTop: 10,
      
     
    },
    media: {
      height: 140,
    },
  });
  

export default ({Poster, Title, Type, Year, imdbID}) => {
    const classes = useStyles();

    
  const [open, setOpen] = useState(false)
  const [data, setData] = useState({})
  const toggle = async(imdbID) => {
    setOpen(!open)
    const data = await fetchInfoOfMovie(imdbID);
    setData(data)
  }
    return (
        <React.Fragment>
            <div style={{padding: '10px'}}>
            <Card className={classes.root}>
        <CardActionArea>
          <CardMedia
            className={classes.media}
            image={Poster}
            title={Title}
          />
          <CardContent>


            <Typography gutterBottom variant="h5" component="h2">
              {Title}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p">
             This {Type} is Released In the Year {Year}
              
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          <Button size="small" color="primary" onClick={toggle} >
            Info
        </Button>
        
        </CardActions>
        </Card>

        <MovieInfo open={open} onClose={()=>toggle(imdbID)} data={data}/>
            </div>
       
      </React.Fragment> 
    )
}