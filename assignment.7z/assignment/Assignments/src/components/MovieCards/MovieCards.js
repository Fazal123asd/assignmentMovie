import React from 'react';
import MovieCard from './MovieCard'



export default props => {

  const { movies } = props



  

  return (
    <div style={{display: 'flex'}}>

      {movies.map(({ Poster, Title, Type, Year, imdbID }, index) => (
        props.category === 'Tab2' ? <MovieCard key={index} Poster={Poster} Title={Title} Type={Type} Year={Year} imdbID={imdbID}/> :
        index+1 === props.currentPage && props.category === 'Tab1'? 
        <MovieCard key={index} Poster={Poster} Title={Title} Type={Type} Year={Year} imdbID={imdbID}/>: null

      ))}


   
    </div>
    
  );
}

