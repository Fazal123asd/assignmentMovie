import axios from 'axios'

const url = 'http://www.omdbapi.com/?s=x%20men&y=2000&apikey=74e5a9cc';


export const fetchMovieData = async () => {
    try {
      const { data: {Search} } = await axios.get(url);
      console.log(Search)
     
      return Search.map(({Title, Year, imdbID, Type, Poster}) => ({Title, Year, imdbID, Type, Poster}))
       
    } catch (error) {
      return error;
    }
  };


  export const fetchInfoOfMovie = async () => {
    try {
      const {data: {Actors, Awards, BoxOffice, Country, DVD, Director, Genre, Language,Metascore,Plot,imdbRating}} = await axios.get(`http://www.omdbapi.com/?i=tt0120903&plot=full&apikey=74e5a9cc`);
       return {Actors, Awards, BoxOffice, Country, DVD, Director, Genre, Language,Metascore,Plot,imdbRating}
    } catch (error) {
      return error;
    }
  };