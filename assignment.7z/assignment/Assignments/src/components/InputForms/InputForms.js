import React, { Component } from 'react'
import { withStyles } from '@material-ui/core/styles';
import { Grid, Paper, TextField, Button } from '@material-ui/core';
import MovieCards from '../MovieCards/MovieCards'
import Pagination from '@material-ui/lab/Pagination';

const styles = theme => ({
    formControl: {
        margin: theme.spacing(1),
        width: 300,

    },
    selectEmpty: {
        marginTop: theme.spacing(100),
    },
})
export default withStyles(styles)(class extends Component {

    state = {
        title: '',
        year: '',
        movie: [],
        currentPage: 1
    }


    handleChange = (name, event) => {
        this.setState({

            ...this.state,

            [name]: event.target.value


        })
    }

    handleSearch = (e) => {

        this.props.movies.filter(({ Title, Year }) => Title.replace(/[:-]/g, "").trim().toLowerCase() === this.state.title.replace(/[:-]/g, "").trim().toLowerCase() && Year.replace(/[–]/g, "").trim() === this.state.year.replace(/[–]/g, "").trim()).map(txt => {

           return  this.setState({ movie: [txt] })
        })

    }

    changeCurrentPage = (event, page) => {
        this.setState({currentPage: page})
    }

    render() {

        const { title, year, movie, currentPage } = this.state
        const { classes, movies, category } = this.props
        return (

            <React.Fragment>
                <Grid container style={{ marginTop: '3px' }}>
                    <Grid item xs={6}>
                        <Paper style={{ padding: '30px', height: '50px' }}>
                            <form style={{ display: 'flex', margin: 'auto' }}>
                                <TextField className={classes.formControl} id="standard-basic" label="Movie Title" value={title} onChange={(event) => this.handleChange("title", event)} />
                                <TextField className={classes.formControl} id="standard-basic1" label="Release Year" value={year} onChange={(event) => this.handleChange("year", event)} />
                                <Button variant="contained" color="primary" style={{ width: '200px' }} onClick={(e) => this.handleSearch(e)}> Search </Button>
                            </form>

                        </Paper>
                    </Grid>

                </Grid>

                <MovieCards movies={movie.length !== 0 && category !== 'Tab2' ? movie : movies} currentPage={currentPage} category={category}/>
                {category !== 'Tab2'?  <Pagination
                    
                    count={5} 
                    color="primary"
                    onChange={(e, page)=>this.changeCurrentPage(e, page)}
                  
                />: null}
               


            </React.Fragment>



        )
    }

})