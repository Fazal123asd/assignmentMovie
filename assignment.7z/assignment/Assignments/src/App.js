import React, { Component } from 'react';
import './App.css';
import Tabs from './components/Tabs/Tabs'
import {fetchMovieData} from './components/Api/Api'
import InputForms from './components/InputForms/InputForms'


class App extends Component {

  state ={
    movies: [],
    category: 'Tab1'
  }

  async componentDidMount(){
    const data = await fetchMovieData();

    this.setState({movies: data})
    
    
  }

   handleCatogory = (category) => {
    this.setState({category})
  }
 
  render(){
    const {movies, category} = this.state;
    return (
      <div className="App">
        <Tabs category={category} onSelect={this.handleCatogory}/>
        <InputForms movies={movies} category={category}/>
      </div>
    );
  }

}

export default App;
